function y = reference_y(u)
y(1) = u; %x_ref
y(2) = 1; %x_ref_dot
y(3) = 0; %x_ref_ddot
y(4) = 0; %x_refd3dot
end